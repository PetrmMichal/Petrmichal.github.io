
import SalesTracker from "@/components/SalesTracker";

const Index = () => {
  return <SalesTracker />;
};

export default Index;
